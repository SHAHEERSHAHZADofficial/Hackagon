var productName = document.getElementById("prtdetail")
var productPrice = document.getElementById("pricedetail")
var imageUrl = document.getElementById("imgUrl")
var productDetail = document.getElementById("productFlex")
db = firebase.firestore()
var details = {
    productName: productName.value,
    price: productPrice.value,
    URL: imageUrl.value,

}

function addProduct() {
    db.collection("storage").add(details)
        .then(() => {
            console.log("done")
            window.location = "./product.html";
            productDetail.innerHTML = details
        })

}

function fetchUsers() {
    var uid = firebase.auth().currentUser.uid;


    var docRef = db.collection("users").doc(uid);
    docRef.get()
        .then((doc) => {
            if (doc.exists) {
                let user = doc.data();
                console.log("Document data:", doc.data(), doc.id, user);
                userImage.src = user.userPic;
                userImage.className = 'user-pic-img';

            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        })
        .catch((error) => {
            console.log("Error getting document:", error);
        });
}