let storage = firebase.storage();
let addProduct = document.getElementById("productflex")
let productName = document.getElementById("productName")


let image = document.getElementsByTagName("img")










let productPrice = document.getElementById("productPrice")
let ProductImage = document.getElementById("ProductImage")
let db = firebase.firestore();

function productdetails() {
    saveUserInFirestore()

}


function saveUserInFirestore(productdetails) {



    db.collection('product').add({
            productName: productName.value,
            productPrice: productPrice.value,
            ProductImage: ProductImage.value
        })
        .then(() => {
            let file = ProductImage.files[0];
            let userPicRefrence = storage.ref().child('images/' + file.name);
            userPicRefrence.put(file)
            var urlimg = userPicRefrence.getDownloadURL()
            console.log(urlimg)
            image.innerHTML = file

        })
        .catch(() => {
            console.error(error)
        })
        .then(() => {
            console.log("Document SAVED ");


        })

    .catch((error) => {
        console.error("Error adding document: ", error);
    });


}